#Average Payment Reduction Rate

select round(avg(PY2020_Payment_Reduction_Percentage),4)as payment_reduction from dialysis2 
where PY2020_Payment_Reduction_Percentage<>0;

