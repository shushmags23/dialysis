#Number of Patients across various summaries

create database project;
use project;

delimiter $$
create procedure patient_summary()
begin
select sum(`No of _patients_included_in_the_transfusion_summary`) as Transfusion_summary,
sum(`No of _patients_in_hypercalcemia_summary`) as 	Hypercalcemia_summary ,
sum(`No of _patient-months_in_hypercalcemia_summary`) as patient_months_in_hypercalcemia_summary,
sum(`No of _patients_in_Serum_phosphorus_summary`) as Serum_phosphorus_summary,
sum(`No of _patient-months_in_Serum_phosphorus_summary_`) as patient_months_in_Serum_phosphorus_summary ,
sum(`No of _patients_included_in_hospitalization_summary`) as hospitalization_summary,
sum(`No of _hospitalizations_included_in_hospital_readmission_summary`) as hospital_readmission_summary,
sum(`No of _Patients_included_in_survival_summary`) as survival_summary,
sum(`No of _Patients_included_in_fistula_summary`) as fistula_summary,
sum(`No of _patients_in_long_term_catheter_summary`) as catheter_summary,
sum(`No of _patient_months_in_long_term_catheter_summary`) as patient_months_catheter_summary,
sum(`No of _patients_in_nPCR_summary`)as nPCR_summary ,
sum(`No of _patient-months_in_nPCR_summary`) as patient_months_in_nPCR_summary
from dialysis1;
end $$
delimiter ;

call patient_summary();







