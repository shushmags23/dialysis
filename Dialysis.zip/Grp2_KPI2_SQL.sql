#Profit Vs Non-Profit Stats

select count(facility_name) as count,`Profit_or_Non-Profit` from dialysis1 group by `Profit_or_Non-Profit`;






