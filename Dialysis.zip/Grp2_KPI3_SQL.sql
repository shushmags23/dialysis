#Chain Organizations w.r.t. Total Performance Score as No Score

select c.Chain_Organization,count(c.Chain_Organization) as Chain_Org_count,(t.Total_Performance_Score) 
from dialysis1 c
inner join dialysis2 T 
using(facility_name)
where t.Total_Performance_Score = 'No Score'
group by c.Chain_Organization;

