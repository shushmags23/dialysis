#of Category Text  - As Expected


select count(Patient_Transfusion_category_text) as Patient_Transfusion_category_text from dialysis1 
where Patient_Transfusion_category_text='as expected';

select count(Patient_hospitalization_category_text) as Patient_hospitalization_category_text from dialysis1
where Patient_hospitalization_category_text='as expected';

select count(Patient_Survival_Category_text) as Patient_Survival_Category_text from dialysis1
where Patient_Survival_Category_text =  'as expected';

select count(Patient_Infection_category_text) as Patient_Infection_category_text from dialysis1
where Patient_Infection_category_text = 'as expected';

select count(Fistula_Category_text) as Fistula_Category_text from dialysis1
where Fistula_Category_Text = 'as expected';

select count(SWR_category_text) as SWR_category_text from dialysis1
where SWR_category_text='as expected';

select count(PPPW_category_text) from dialysis1
where PPPW_category_text = 'as expected';




