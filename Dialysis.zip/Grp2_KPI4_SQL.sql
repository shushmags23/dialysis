#Dialysis Stations Stats

select Chain_Organization,sum( No_of_Dialysis_Stations) as total_ds
from dialysis1
group by Chain_Organization 
order by sum(No_of_Dialysis_Stations) desc
limit 5;

